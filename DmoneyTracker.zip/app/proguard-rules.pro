# Règles ProGuard par défaut. Room et Compose fonctionnent sans règles additionnelles ici.
-keepattributes *Annotation*

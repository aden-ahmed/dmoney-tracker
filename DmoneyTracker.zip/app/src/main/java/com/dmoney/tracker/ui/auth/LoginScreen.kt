package com.dmoney.tracker.ui.auth

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Password
import androidx.compose.material3.Button
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.dmoney.tracker.data.User
import com.dmoney.tracker.security.BiometricAuth
import com.dmoney.tracker.ui.components.NumericKeypad
import com.dmoney.tracker.ui.components.PinDots
import com.dmoney.tracker.ui.components.VSpace
import com.dmoney.tracker.ui.components.findFragmentActivity

private const val MAX_PIN = 6

@Composable
fun LoginScreen(authVm: AuthViewModel, user: User?) {
    val context = LocalContext.current
    val activity = remember { context.findFragmentActivity() }
    var pin by remember { mutableStateOf("") }
    var usePassword by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    val error = authVm.error
    val biometricReady = user?.biometricEnabled == true && BiometricAuth.isAvailable(context)

    fun tryBiometric() {
        val act = activity ?: return
        BiometricAuth.authenticate(
            activity = act,
            title = "Déverrouiller Dmoney Tracker",
            subtitle = "Utilisez votre empreinte digitale",
            negativeButton = "Utiliser le PIN",
            onSuccess = { authVm.onBiometricSuccess() },
            onError = { /* silencieux : l'utilisateur peut saisir le PIN */ }
        )
    }

    // Propose la biométrie automatiquement à l'ouverture.
    LaunchedEffect(biometricReady) {
        if (biometricReady) tryBiometric()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            BrandLogo()
            VSpace(16)
            Text(
                "Dmoney Tracker",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                user?.username ?: "",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            VSpace(28)

            if (usePassword) {
                Text("Mot de passe", style = MaterialTheme.typography.titleMedium)
                VSpace(12)
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; authVm.clearError() },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.widthIn(max = 320.dp).fillMaxWidth()
                )
                VSpace(12)
                Button(
                    onClick = { authVm.unlockWithPassword(password) },
                    enabled = password.isNotEmpty(),
                    modifier = Modifier.widthIn(max = 320.dp).fillMaxWidth()
                ) { Text("Se connecter") }
            } else {
                Text("Entrez votre code PIN", style = MaterialTheme.typography.titleMedium)
                VSpace(20)
                PinDots(entered = pin.length, max = MAX_PIN)
                VSpace(20)
                NumericKeypad(
                    modifier = Modifier.widthIn(max = 340.dp),
                    onDigit = { d ->
                        if (pin.length < MAX_PIN) {
                            pin += d.toString()
                            authVm.clearError()
                            if (pin.length in 4..MAX_PIN) {
                                // Validation possible dès 4 chiffres via le bouton ci-dessous.
                            }
                        }
                    },
                    onBackspace = { if (pin.isNotEmpty()) pin = pin.dropLast(1) }
                )
                VSpace(16)
                Button(
                    onClick = { authVm.unlockWithPin(pin) },
                    enabled = pin.length in 4..MAX_PIN,
                    modifier = Modifier.widthIn(max = 340.dp).fillMaxWidth()
                ) { Text("Déverrouiller") }
            }

            if (error != null) {
                VSpace(12)
                Text(
                    error,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            }

            VSpace(24)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                if (biometricReady) {
                    AuthActionIcon(Icons.Filled.Fingerprint, "Empreinte") { tryBiometric() }
                }
                AuthActionIcon(
                    if (usePassword) Icons.Filled.Password else Icons.Filled.Password,
                    if (usePassword) "Utiliser le PIN" else "Mot de passe"
                ) {
                    usePassword = !usePassword
                    authVm.clearError()
                }
            }
        }
    }
}

@Composable
private fun Row(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    content: @Composable () -> Unit
) {
    androidx.compose.foundation.layout.Row(
        modifier = modifier,
        horizontalArrangement = horizontalArrangement,
        verticalAlignment = Alignment.CenterVertically
    ) { content() }
}

@Composable
private fun AuthActionIcon(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 16.dp)) {
        FilledIconButton(onClick = onClick, modifier = Modifier.size(56.dp)) {
            Icon(icon, contentDescription = label)
        }
        VSpace(6)
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun BrandLogo() {
    Surface(
        modifier = Modifier.size(84.dp).clip(CircleShape),
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = CircleShape
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                "D",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

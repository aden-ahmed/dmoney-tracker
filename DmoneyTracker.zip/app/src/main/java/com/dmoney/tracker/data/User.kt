package com.dmoney.tracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Utilisateur unique de l'application.
 * Un seul enregistrement existe (id = 1). Le PIN et le mot de passe sont stockés hachés.
 */
@Entity(tableName = "user")
data class User(
    @PrimaryKey val id: Int = SINGLE_USER_ID,
    val username: String,
    val pinHash: String,
    val pinSalt: String,
    val passwordHash: String? = null,
    val passwordSalt: String? = null,
    val biometricEnabled: Boolean = false
) {
    companion object {
        const val SINGLE_USER_ID = 1
    }
}

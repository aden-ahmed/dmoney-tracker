package com.dmoney.tracker.ui.components

import android.content.Context
import android.content.ContextWrapper
import androidx.fragment.app.FragmentActivity

/** Retrouve la FragmentActivity hôte depuis un Context Compose. */
fun Context.findFragmentActivity(): FragmentActivity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is FragmentActivity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

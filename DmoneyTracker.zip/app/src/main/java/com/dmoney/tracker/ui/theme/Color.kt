package com.dmoney.tracker.ui.theme

import androidx.compose.ui.graphics.Color

// Palette de marque : vert émeraude profond (finance) + accents ambre.
val Emerald10 = Color(0xFF00210F)
val Emerald20 = Color(0xFF00391D)
val Emerald30 = Color(0xFF00522C)
val Emerald40 = Color(0xFF006D3C)
val Emerald80 = Color(0xFF6ADBA0)
val Emerald90 = Color(0xFF88F8BB)

val Teal40 = Color(0xFF006A66)
val Teal80 = Color(0xFF50DBD4)

val Amber40 = Color(0xFF8A5300)
val Amber80 = Color(0xFFFFB954)

val NeutralLightBg = Color(0xFFF6FBF4)
val NeutralLightSurface = Color(0xFFFFFFFF)
val NeutralDarkBg = Color(0xFF0E1511)
val NeutralDarkSurface = Color(0xFF151D18)

val DangerRed = Color(0xFFBA1A1A)

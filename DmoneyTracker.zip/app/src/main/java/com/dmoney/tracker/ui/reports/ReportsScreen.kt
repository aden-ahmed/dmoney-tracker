package com.dmoney.tracker.ui.reports

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dmoney.tracker.ui.components.SegmentedControl
import com.dmoney.tracker.util.DateUtils
import com.dmoney.tracker.util.Money

@Composable
fun ReportsScreen(modifier: Modifier = Modifier) {
    val vm: ReportsViewModel = viewModel()
    val reports by vm.reports.collectAsStateWithLifecycle()
    val transactions by vm.transactions.collectAsStateWithLifecycle()
    val ui = vm.ui

    val grandAmount = ReportBuilder.grandAmount(reports)
    val grandCount = ReportBuilder.grandCount(reports)

    val periodLabels = listOf("Jour", "Semaine", "Mois", "Plage", "Heure")

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Rapports", style = MaterialTheme.typography.headlineSmall)
        }
        item {
            SegmentedControl(
                options = periodLabels,
                selectedIndex = ui.periodType.ordinal,
                onSelect = { vm.setPeriod(PeriodType.entries[it]) },
                compact = true
            )
        }
        item {
            PeriodNavigator(vm)
        }
        item {
            GrandTotalCard(count = grandCount, amount = grandAmount)
        }

        if (reports.isEmpty()) {
            item { EmptyReports() }
        } else {
            items(reports, key = { it.category.key }) { report ->
                CategoryReportCard(
                    report = report,
                    transactions = transactions,
                    onToggleExclude = { vm.toggleExcluded(it) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PeriodNavigator(vm: ReportsViewModel) {
    val ui = vm.ui
    var showPicker by remember { mutableStateOf(false) }
    var pickingRangeStart by remember { mutableStateOf(true) }
    var showStartTime by remember { mutableStateOf(false) }
    var showEndTime by remember { mutableStateOf(false) }

    val label = when (ui.periodType) {
        PeriodType.JOUR -> DateUtils.formatDay(ui.reference)
        PeriodType.SEMAINE -> DateUtils.formatWeekLabel(DateUtils.week(ui.reference))
        PeriodType.MOIS -> DateUtils.formatMonth(ui.reference)
        PeriodType.PLAGE -> "${DateUtils.formatDay(ui.rangeFrom)} → ${DateUtils.formatDay(ui.rangeTo)}"
        PeriodType.HEURE -> DateUtils.formatDay(ui.hourDay)
    }

    Card {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (ui.periodType != PeriodType.PLAGE) {
                IconButton(onClick = { vm.previous() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Précédent")
                }
            }
            Text(
                label,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium
            )
            IconButton(onClick = {
                pickingRangeStart = true
                showPicker = true
            }) {
                Icon(Icons.Filled.CalendarMonth, contentDescription = "Choisir une date")
            }
            if (ui.periodType != PeriodType.PLAGE) {
                IconButton(onClick = { vm.next() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Suivant")
                }
            }
        }
    }

    if (ui.periodType == PeriodType.PLAGE) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { pickingRangeStart = true; showPicker = true },
                modifier = Modifier.weight(1f)
            ) { Text("Du : ${DateUtils.formatDay(ui.rangeFrom)}") }
            OutlinedButton(
                onClick = { pickingRangeStart = false; showPicker = true },
                modifier = Modifier.weight(1f)
            ) { Text("Au : ${DateUtils.formatDay(ui.rangeTo)}") }
        }
    }

    if (ui.periodType == PeriodType.HEURE) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { showStartTime = true },
                modifier = Modifier.weight(1f)
            ) {
                Text("De  ${DateUtils.formatSecOfDay(ui.startSecOfDay)}")
            }
            OutlinedButton(
                onClick = { showEndTime = true },
                modifier = Modifier.weight(1f)
            ) {
                Text("À  ${DateUtils.formatSecOfDay(ui.endSecOfDay)}")
            }
        }
    }

    if (showPicker) {
        val initial = when {
            ui.periodType == PeriodType.PLAGE && pickingRangeStart -> ui.rangeFrom
            ui.periodType == PeriodType.PLAGE -> ui.rangeTo
            ui.periodType == PeriodType.HEURE -> ui.hourDay
            else -> ui.reference
        }
        val state = rememberDatePickerState(initialSelectedDateMillis = initial)
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    val picked = state.selectedDateMillis
                    if (picked != null) {
                        when {
                            ui.periodType == PeriodType.PLAGE && pickingRangeStart ->
                                vm.setCustomRange(picked, ui.rangeTo)
                            ui.periodType == PeriodType.PLAGE ->
                                vm.setCustomRange(ui.rangeFrom, picked)
                            ui.periodType == PeriodType.HEURE ->
                                vm.setHourDay(picked)
                            else -> vm.setReference(picked)
                        }
                    }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showPicker = false }) { Text("Annuler") }
            }
        ) {
            DatePicker(state = state)
        }
    }

    if (showStartTime) {
        TimeSecondsPickerDialog(
            title = "Heure de début",
            initialSecOfDay = ui.startSecOfDay,
            onConfirm = { vm.setHourStart(it); showStartTime = false },
            onDismiss = { showStartTime = false }
        )
    }
    if (showEndTime) {
        TimeSecondsPickerDialog(
            title = "Heure de fin",
            initialSecOfDay = ui.endSecOfDay,
            onConfirm = { vm.setHourEnd(it); showEndTime = false },
            onDismiss = { showEndTime = false }
        )
    }
}

/** Sélecteur d'heure précis : heures, minutes et secondes. */
@Composable
private fun TimeSecondsPickerDialog(
    title: String,
    initialSecOfDay: Int,
    onConfirm: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var hours by remember { mutableStateOf(DateUtils.hourOf(initialSecOfDay).toString()) }
    var minutes by remember { mutableStateOf(DateUtils.minuteOf(initialSecOfDay).toString()) }
    var seconds by remember { mutableStateOf(DateUtils.secondOf(initialSecOfDay).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TimeNumberField("Heures", hours, 23) { hours = it }
                TimeNumberField("Minutes", minutes, 59) { minutes = it }
                TimeNumberField("Secondes", seconds, 59) { seconds = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val h = hours.toIntOrNull() ?: 0
                val m = minutes.toIntOrNull() ?: 0
                val s = seconds.toIntOrNull() ?: 0
                onConfirm(DateUtils.secOfDay(h, m, s))
            }) { Text("OK") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}

@Composable
private fun RowScope.TimeNumberField(
    label: String,
    value: String,
    max: Int,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = { input ->
            val digits = input.filter { it.isDigit() }.take(2)
            val n = digits.toIntOrNull()
            if (digits.isEmpty() || (n != null && n <= max)) onChange(digits)
        },
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f)
    )
}

@Composable
private fun GrandTotalCard(count: Int, amount: Long) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Total de la période", style = MaterialTheme.typography.titleMedium)
                Text("$count opération(s)", style = MaterialTheme.typography.bodyMedium)
            }
            Text(
                Money.formatDjf(amount),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun EmptyReports() {
    Card(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier.fillMaxWidth().padding(28.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Aucune opération sur cette période",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

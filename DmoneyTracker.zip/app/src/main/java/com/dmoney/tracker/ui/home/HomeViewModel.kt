package com.dmoney.tracker.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dmoney.tracker.data.Repository
import com.dmoney.tracker.ui.reports.CategoryReport
import com.dmoney.tracker.ui.reports.ReportBuilder
import com.dmoney.tracker.util.DateUtils
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository.get(app)
    private val today = DateUtils.day(System.currentTimeMillis())

    val todayReports: StateFlow<List<CategoryReport>> =
        repo.observeBetween(today.from, today.to)
            .map { ReportBuilder.build(it) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalCount: StateFlow<Int> =
        repo.observeAll()
            .map { it.size }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
}

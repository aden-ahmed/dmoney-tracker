package com.dmoney.tracker.parser

import com.dmoney.tracker.data.Category
import com.dmoney.tracker.data.Txn
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Analyse le texte d'une notification Dmoney et le décompose en une [Txn].
 *
 * Trois modèles connus sont reconnus (dépôt / crédit abonné, crédit téléphonique,
 * retrait d'espèce). Tout autre message Dmoney est rangé dans la catégorie AUTRE
 * avec un sous-type déduit, et le montant éventuel est extrait.
 */
object DmoneyParser {

    private val dateRegex = Regex("""(\d{2}/\d{2}/\d{4})\s+(\d{2}:\d{2}:\d{2})""")
    private val opIdRegex = Regex("""identifiant de l['’]op[ée]ration est\s*([0-9]+)""", RegexOption.IGNORE_CASE)

    // Montant : suite de chiffres avec séparateurs de milliers (virgule, point, espace).
    private const val NUM = """([0-9][0-9.,\s ]*[0-9]|[0-9])"""

    private val debiteRegex = Regex("""d[ée]bit[ée](?:\sde)?\s+$NUM\s*(?:DJF|FDJ)?""", RegexOption.IGNORE_CASE)
    private val valeurRegex = Regex("""valeur de\s+$NUM\s*(?:DJF|FDJ)?""", RegexOption.IGNORE_CASE)
    private val soldeRegex = Regex("""solde[^0-9]*$NUM\s*(?:DJF|FDJ)?""", RegexOption.IGNORE_CASE)
    private val fraisRegex = Regex("""frais de\s+$NUM\s*(?:DJF|FDJ)?""", RegexOption.IGNORE_CASE)
    private val abonneRegex = Regex("""l['’]abonn[ée]\s+([0-9]+)""", RegexOption.IGNORE_CASE)
    private val numeroRegex = Regex("""num[ée]ro\s+([0-9]+)""", RegexOption.IGNORE_CASE)
    private val agentRegex = Regex("""l['’]agent\s+([0-9]+)""", RegexOption.IGNORE_CASE)

    /**
     * Vrai si le texte ressemble à un message financier Dmoney.
     * Sert à éviter de capturer des notifications sans rapport.
     */
    fun looksLikeDmoney(text: String): Boolean {
        val t = text.lowercase(Locale.FRENCH)
        val hasMoney = t.contains("djf") || t.contains("fdj")
        val hasMarker = t.contains("compte principal") ||
            t.contains("identifiant de l'op") ||
            t.contains("identifiant de l’op") ||
            t.contains("solde")
        val known = t.contains("crédité") || t.contains("credite") ||
            t.contains("crédit téléphonique") || t.contains("credit telephonique") ||
            t.contains("retrait")
        return (hasMoney && hasMarker) || known
    }

    /**
     * Distingue Dmoney de "D-money" (applications différentes).
     * On écarte explicitement les sources nommées « D-money / D money ».
     */
    fun isExcludedSource(appName: String?, title: String?): Boolean {
        val hay = ((appName ?: "") + " " + (title ?: "")).lowercase(Locale.ROOT)
        // "d-money", "d money", "d_money" => exclure ; "dmoney" => accepter.
        return Regex("""d[\s\-_]money""").containsMatchIn(hay)
    }

    fun parse(
        text: String,
        title: String?,
        sourcePackage: String?,
        sourceApp: String?,
        receivedAt: Long
    ): Txn? {
        val clean = text.replace('\n', ' ').replace(Regex("""\s+"""), " ").trim()
        if (clean.isEmpty()) return null
        if (!looksLikeDmoney(clean)) return null

        val lower = clean.lowercase(Locale.FRENCH)
        val occurredText = dateRegex.find(clean)?.let { "${it.groupValues[1]} ${it.groupValues[2]}" }
        val occurredAt = occurredText?.let { parseDate(it) } ?: receivedAt
        val operationId = opIdRegex.find(clean)?.groupValues?.get(1)
        val fees = fraisRegex.find(clean)?.let { amount(it.groupValues[1]) } ?: 0L
        val balance = soldeRegex.find(clean)?.let { amount(it.groupValues[1]) }

        val base = Txn(
            categoryKey = Category.AUTRE.key,
            amount = 0L,
            fees = fees,
            balanceAfter = balance,
            operationId = operationId,
            occurredAt = occurredAt,
            occurredText = occurredText,
            receivedAt = receivedAt,
            rawMessage = clean,
            sourcePackage = sourcePackage,
            sourceApp = sourceApp,
            title = title
        )

        // 1) Dépôt / crédit à l'abonné
        if (lower.contains("crédité") || lower.contains("credite") || abonneRegex.containsMatchIn(clean)) {
            val abonne = abonneRegex.find(clean)?.groupValues?.get(1)
            val montant = debiteRegex.find(clean)?.let { amount(it.groupValues[1]) } ?: 0L
            return base.copy(
                categoryKey = Category.DEPOT.key,
                subType = "Crédit abonné",
                amount = montant,
                counterparty = abonne,
                counterpartyType = "ABONNE"
            )
        }

        // 2) Crédit téléphonique
        if (lower.contains("crédit téléphonique") || lower.contains("credit telephonique") ||
            (lower.contains("crédit") && lower.contains("numéro"))
        ) {
            val numero = numeroRegex.find(clean)?.groupValues?.get(1)
            val montant = valeurRegex.find(clean)?.let { amount(it.groupValues[1]) }
                ?: debiteRegex.find(clean)?.let { amount(it.groupValues[1]) } ?: 0L
            return base.copy(
                categoryKey = Category.AIRTIME.key,
                subType = "Crédit téléphonique",
                amount = montant,
                counterparty = numero,
                counterpartyType = "NUMERO"
            )
        }

        // 3) Retrait d'espèce
        if (lower.contains("retrait")) {
            val agent = agentRegex.find(clean)?.groupValues?.get(1)
            val montant = debiteRegex.find(clean)?.let { amount(it.groupValues[1]) } ?: 0L
            return base.copy(
                categoryKey = Category.RETRAIT.key,
                subType = "Retrait d'espèce",
                amount = montant,
                counterparty = agent,
                counterpartyType = "AGENT"
            )
        }

        // 4) Autre message Dmoney : on conserve avec un montant déduit si possible.
        val montantAutre = debiteRegex.find(clean)?.let { amount(it.groupValues[1]) }
            ?: valeurRegex.find(clean)?.let { amount(it.groupValues[1]) } ?: 0L
        return base.copy(
            categoryKey = Category.AUTRE.key,
            subType = deriveSubType(lower),
            amount = montantAutre
        )
    }

    private fun deriveSubType(lower: String): String = when {
        lower.contains("transfert") -> "Transfert"
        lower.contains("paiement") -> "Paiement"
        lower.contains("facture") -> "Facture"
        lower.contains("reçu") || lower.contains("recu") -> "Réception"
        lower.contains("annul") -> "Annulation"
        lower.contains("commission") -> "Commission"
        else -> "Autre opération"
    }

    /** Convertit "11,852" / "1 000" / "200DJF" en entier DJF. */
    fun amount(raw: String): Long {
        val digits = raw.replace(Regex("""[^0-9]"""), "")
        return digits.toLongOrNull() ?: 0L
    }

    private fun parseDate(s: String): Long? = try {
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE)
        fmt.isLenient = false
        fmt.parse(s)?.time
    } catch (e: Exception) {
        null
    }
}

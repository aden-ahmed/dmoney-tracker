package com.dmoney.tracker

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dmoney.tracker.ui.MainScaffold
import com.dmoney.tracker.ui.auth.AuthViewModel
import com.dmoney.tracker.ui.auth.LoginScreen
import com.dmoney.tracker.ui.theme.DmoneyTrackerTheme

/**
 * FragmentActivity est requis par BiometricPrompt (empreinte digitale).
 */
class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            DmoneyTrackerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val authVm: AuthViewModel = viewModel()
                    val user by authVm.user.collectAsStateWithLifecycle()

                    if (!authVm.unlocked) {
                        LoginScreen(authVm = authVm, user = user)
                    } else {
                        MainScaffold(authVm = authVm, user = user)
                    }
                }
            }
        }
    }
}

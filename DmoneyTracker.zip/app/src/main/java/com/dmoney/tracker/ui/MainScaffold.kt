package com.dmoney.tracker.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.dmoney.tracker.data.User
import com.dmoney.tracker.ui.auth.AuthViewModel
import com.dmoney.tracker.ui.home.HomeScreen
import com.dmoney.tracker.ui.reports.ReportsScreen
import com.dmoney.tracker.ui.settings.SettingsScreen
import com.dmoney.tracker.ui.transactions.TransactionsScreen

private data class Tab(val label: String, val icon: ImageVector)

@Composable
fun MainScaffold(authVm: AuthViewModel, user: User?) {
    var selected by remember { mutableIntStateOf(0) }
    val tabs = remember {
        listOf(
            Tab("Accueil", Icons.Filled.Home),
            Tab("Rapports", Icons.Filled.BarChart),
            Tab("Transactions", Icons.AutoMirrored.Filled.ReceiptLong),
            Tab("Réglages", Icons.Filled.Settings)
        )
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selected == index,
                        onClick = { selected = index },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { inner ->
        val contentModifier = Modifier
            .fillMaxSize()
            .padding(inner)
        when (selected) {
            0 -> HomeScreen(modifier = contentModifier, onOpenReports = { selected = 1 })
            1 -> ReportsScreen(modifier = contentModifier)
            2 -> TransactionsScreen(modifier = contentModifier)
            else -> SettingsScreen(modifier = contentModifier, authVm = authVm, user = user)
        }
    }
}

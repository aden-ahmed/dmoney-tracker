package com.dmoney.tracker.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.DisposableEffect
import com.dmoney.tracker.notif.NotificationAccess
import com.dmoney.tracker.security.SessionManager
import com.dmoney.tracker.ui.reports.CategoryReport
import com.dmoney.tracker.ui.components.VSpace
import com.dmoney.tracker.util.Money

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    onOpenReports: () -> Unit
) {
    val vm: HomeViewModel = viewModel()
    val context = LocalContext.current
    val session = remember { SessionManager(context) }
    val todayReports by vm.todayReports.collectAsStateWithLifecycle()
    val totalCount by vm.totalCount.collectAsStateWithLifecycle()

    // Statut d'accès aux notifications, réévalué au retour sur l'écran.
    var accessGranted by remember { mutableStateOf(NotificationAccess.isEnabled(context)) }
    var captureEnabled by remember { mutableStateOf(session.captureEnabled) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                accessGranted = NotificationAccess.isEnabled(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Tableau de bord", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Suivi des opérations Dmoney",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        VSpace(16)

        NotificationAccessCard(
            granted = accessGranted,
            onEnable = { context.startActivity(NotificationAccess.settingsIntent()) }
        )
        VSpace(12)

        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Capture des notifications", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (captureEnabled) "Active" else "En pause",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = captureEnabled,
                    onCheckedChange = {
                        captureEnabled = it
                        session.captureEnabled = it
                    }
                )
            }
        }
        VSpace(20)

        Text("Aujourd'hui", style = MaterialTheme.typography.titleLarge)
        VSpace(4)
        Text(
            "$totalCount opération(s) enregistrée(s) au total",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        VSpace(12)

        if (todayReports.isEmpty()) {
            EmptyToday()
        } else {
            todayReports.forEach { report ->
                CategorySummaryCard(report)
                VSpace(10)
            }
        }

        VSpace(12)
        Button(onClick = onOpenReports, modifier = Modifier.fillMaxWidth()) {
            Text("Voir les rapports détaillés")
        }
        VSpace(24)
    }
}

@Composable
private fun NotificationAccessCard(granted: Boolean, onEnable: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (granted)
                MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (granted) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                    contentDescription = null,
                    tint = if (granted) MaterialTheme.colorScheme.onPrimaryContainer
                    else MaterialTheme.colorScheme.onErrorContainer
                )
                Text(
                    if (granted) "Accès aux notifications accordé"
                    else "Accès aux notifications requis",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (granted) MaterialTheme.colorScheme.onPrimaryContainer
                    else MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.padding(start = 10.dp)
                )
            }
            if (!granted) {
                VSpace(8)
                Text(
                    "Autorisez l'application à lire les notifications pour capturer automatiquement les messages Dmoney.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                VSpace(12)
                Button(onClick = onEnable) { Text("Activer l'accès") }
            }
        }
    }
}

@Composable
private fun CategorySummaryCard(report: CategoryReport) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(report.category.label, style = MaterialTheme.typography.titleMedium)
                Text(
                    "${report.totalCount} opération(s)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                Money.formatDjf(report.totalAmount),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun EmptyToday() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
            Text(
                "Aucune opération aujourd'hui",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

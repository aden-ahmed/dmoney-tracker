package com.dmoney.tracker.ui.transactions

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dmoney.tracker.data.Category
import com.dmoney.tracker.data.Txn
import com.dmoney.tracker.util.DateUtils
import com.dmoney.tracker.util.Money

@Composable
fun TransactionsScreen(modifier: Modifier = Modifier) {
    val vm: TransactionsViewModel = viewModel()
    val txns by vm.transactions.collectAsStateWithLifecycle()
    val selected = vm.selectedCategory

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Transactions", style = MaterialTheme.typography.headlineSmall)
        }
        item {
            OutlinedTextField(
                value = vm.searchQuery,
                onValueChange = { vm.setSearch(it) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Rechercher (identifiant, numéro, montant)") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (vm.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { vm.setSearch("") }) {
                            Icon(Icons.Filled.Close, contentDescription = "Effacer")
                        }
                    }
                }
            )
        }
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selected == null,
                    onClick = { vm.setFilter(null) },
                    label = { Text("Toutes") }
                )
                Category.displayOrder.forEach { cat ->
                    FilterChip(
                        selected = selected == cat,
                        onClick = { vm.setFilter(cat) },
                        label = { Text(cat.label) }
                    )
                }
            }
        }

        if (txns.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (vm.searchQuery.isNotEmpty())
                            "Aucun résultat pour \"${vm.searchQuery}\""
                        else "Aucune transaction",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(txns, key = { it.id }) { txn ->
                TxnCard(txn = txn, onToggle = { vm.toggleExcluded(txn) })
            }
        }
    }
}

@Composable
private fun TxnCard(txn: Txn, onToggle: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        Category.fromKey(txn.categoryKey).label,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        txn.occurredText ?: DateUtils.formatDayTime(txn.occurredAt),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    Money.formatDjf(txn.amount),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textDecoration = if (txn.excluded) TextDecoration.LineThrough else null,
                    color = if (txn.excluded) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.primary
                )
            }

            if (txn.excluded) {
                Text(
                    "N'est pas compté",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AssistChip(
                    onClick = onToggle,
                    label = { Text(if (txn.excluded) "Recompter" else "N'est pas compté") }
                )
                Box(modifier = Modifier.weight(1f))
                TextButton(onClick = { expanded = !expanded }) {
                    Text(if (expanded) "Masquer" else "Détails")
                    Icon(Icons.Filled.ExpandMore, contentDescription = null)
                }
            }

            if (expanded) {
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                DetailLine("Identifiant", txn.operationId ?: "—")
                txn.counterparty?.let {
                    DetailLine(
                        when (txn.counterpartyType) {
                            "ABONNE" -> "Abonné"
                            "NUMERO" -> "Numéro"
                            "AGENT" -> "Agent"
                            else -> "Contrepartie"
                        },
                        it
                    )
                }
                if (txn.fees > 0) DetailLine("Frais", Money.formatDjf(txn.fees))
                txn.balanceAfter?.let { DetailLine("Nouveau solde", Money.formatDjf(it)) }
                txn.subType?.let { DetailLine("Type", it) }
                txn.sourceApp?.let { DetailLine("Source", it) }
                Text(
                    txn.rawMessage,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
        )
    }
}

package com.dmoney.tracker.ui.reports

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dmoney.tracker.data.Repository
import com.dmoney.tracker.data.Txn
import com.dmoney.tracker.util.DateRange
import com.dmoney.tracker.util.DateUtils
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class PeriodType { JOUR, SEMAINE, MOIS, PLAGE }

data class ReportUiState(
    val periodType: PeriodType = PeriodType.JOUR,
    val reference: Long = System.currentTimeMillis(),
    val rangeFrom: Long = System.currentTimeMillis(),
    val rangeTo: Long = System.currentTimeMillis()
) {
    fun range(): DateRange = when (periodType) {
        PeriodType.JOUR -> DateUtils.day(reference)
        PeriodType.SEMAINE -> DateUtils.week(reference)
        PeriodType.MOIS -> DateUtils.month(reference)
        PeriodType.PLAGE -> DateUtils.range(rangeFrom, rangeTo)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class ReportsViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository.get(app)

    var ui by mutableStateOf(ReportUiState())
        private set

    private val rangeFlow = MutableStateFlow(ui.range())

    val transactions: StateFlow<List<Txn>> = rangeFlow
        .flatMapLatest { r -> repo.observeBetween(r.from, r.to) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reports: StateFlow<List<CategoryReport>> = transactions
        .map { ReportBuilder.build(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private fun apply(newUi: ReportUiState) {
        ui = newUi
        rangeFlow.value = newUi.range()
    }

    fun setPeriod(type: PeriodType) = apply(ui.copy(periodType = type))

    fun previous() = apply(
        when (ui.periodType) {
            PeriodType.JOUR -> ui.copy(reference = DateUtils.shiftDay(ui.reference, -1))
            PeriodType.SEMAINE -> ui.copy(reference = DateUtils.shiftWeek(ui.reference, -1))
            PeriodType.MOIS -> ui.copy(reference = DateUtils.shiftMonth(ui.reference, -1))
            PeriodType.PLAGE -> ui
        }
    )

    fun next() = apply(
        when (ui.periodType) {
            PeriodType.JOUR -> ui.copy(reference = DateUtils.shiftDay(ui.reference, 1))
            PeriodType.SEMAINE -> ui.copy(reference = DateUtils.shiftWeek(ui.reference, 1))
            PeriodType.MOIS -> ui.copy(reference = DateUtils.shiftMonth(ui.reference, 1))
            PeriodType.PLAGE -> ui
        }
    )

    fun setReference(millis: Long) = apply(ui.copy(reference = millis))

    fun setCustomRange(from: Long, to: Long) {
        val lo = minOf(from, to)
        val hi = maxOf(from, to)
        apply(ui.copy(periodType = PeriodType.PLAGE, rangeFrom = lo, rangeTo = hi))
    }

    fun toggleExcluded(txn: Txn) {
        viewModelScope.launch { repo.setExcluded(txn.id, !txn.excluded) }
    }
}

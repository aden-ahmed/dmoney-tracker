package com.dmoney.tracker.ui.settings

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dmoney.tracker.data.User
import com.dmoney.tracker.notif.NotificationAccess
import com.dmoney.tracker.security.BiometricAuth
import com.dmoney.tracker.security.SessionManager
import com.dmoney.tracker.ui.auth.AuthViewModel
import com.dmoney.tracker.ui.components.VSpace
import com.dmoney.tracker.ui.components.findFragmentActivity

@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier,
    authVm: AuthViewModel,
    user: User?
) {
    val vm: SettingsViewModel = viewModel()
    val context = LocalContext.current
    val activity = remember { context.findFragmentActivity() }
    val session = remember { SessionManager(context) }
    val txnCount by vm.txnCount.collectAsStateWithLifecycle()

    var showPinDialog by remember { mutableStateOf(false) }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var showAppPicker by remember { mutableStateOf(false) }
    var showUsernameDialog by remember { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }

    var targetLabel by remember { mutableStateOf(session.targetAppLabel) }
    var captureEnabled by remember { mutableStateOf(session.captureEnabled) }

    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Réglages", style = MaterialTheme.typography.headlineSmall)
        VSpace(16)

        // -------- Compte --------
        SectionTitle("Compte")
        SettingsCard {
            SettingRow(
                title = "Identifiant",
                subtitle = user?.username ?: "—",
                onClick = { showUsernameDialog = true }
            )
        }
        VSpace(16)

        // -------- Sécurité --------
        SectionTitle("Sécurité")
        SettingsCard {
            SettingRow(
                title = "Modifier le code PIN",
                subtitle = "4 à 6 chiffres",
                onClick = { showPinDialog = true }
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            SettingRow(
                title = "Mot de passe",
                subtitle = if (user?.passwordHash != null) "Défini" else "Non défini",
                onClick = { showPasswordDialog = true }
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            SettingToggleRow(
                title = "Déverrouillage par empreinte",
                subtitle = "Utiliser la biométrie à l'ouverture",
                checked = user?.biometricEnabled == true,
                onCheckedChange = { enable ->
                    if (enable) {
                        val act = activity
                        if (act != null && BiometricAuth.isAvailable(context)) {
                            BiometricAuth.authenticate(
                                activity = act,
                                title = "Activer l'empreinte",
                                subtitle = "Confirmez votre empreinte digitale",
                                negativeButton = "Annuler",
                                onSuccess = { authVm.setBiometric(true) },
                                onError = {
                                    Toast.makeText(context, "Échec: $it", Toast.LENGTH_SHORT).show()
                                }
                            )
                        } else {
                            Toast.makeText(
                                context,
                                "Aucune empreinte configurée sur l'appareil",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    } else {
                        authVm.setBiometric(false)
                    }
                }
            )
        }
        VSpace(16)

        // -------- Capture Dmoney --------
        SectionTitle("Capture Dmoney")
        SettingsCard {
            SettingRow(
                title = "Accès aux notifications",
                subtitle = if (NotificationAccess.isEnabled(context)) "Accordé" else "Non accordé — appuyez pour activer",
                onClick = { context.startActivity(NotificationAccess.settingsIntent()) }
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            SettingRow(
                title = "Application source",
                subtitle = targetLabel ?: "Détection automatique (Dmoney)",
                onClick = {
                    vm.loadInstalledApps()
                    showAppPicker = true
                }
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            SettingToggleRow(
                title = "Capture active",
                subtitle = "Enregistrer les nouveaux messages",
                checked = captureEnabled,
                onCheckedChange = {
                    captureEnabled = it
                    session.captureEnabled = it
                }
            )
        }
        VSpace(16)

        // -------- Données --------
        SectionTitle("Données")
        SettingsCard {
            SettingRow(
                title = "Transactions enregistrées",
                subtitle = "$txnCount au total",
                onClick = {}
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            SettingRow(
                title = "Effacer toutes les transactions",
                subtitle = "Action irréversible",
                onClick = { showClearDialog = true }
            )
        }
        VSpace(16)

        OutlinedButton(
            onClick = { authVm.lock() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Verrouiller l'application") }

        VSpace(16)
        Text(
            "Dmoney Tracker • v1.0",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        VSpace(24)
    }

    // -------- Dialogues --------
    if (showPinDialog) {
        PinChangeDialog(
            onDismiss = { showPinDialog = false },
            onConfirm = { pin ->
                authVm.changePin(pin) { ok, err ->
                    Toast.makeText(
                        context,
                        if (ok) "Code PIN mis à jour" else (err ?: "Erreur"),
                        Toast.LENGTH_SHORT
                    ).show()
                    if (ok) showPinDialog = false
                }
            }
        )
    }

    if (showPasswordDialog) {
        PasswordDialog(
            hasPassword = user?.passwordHash != null,
            onDismiss = { showPasswordDialog = false },
            onConfirm = { pwd ->
                authVm.changePassword(pwd) { _, _ ->
                    Toast.makeText(context, "Mot de passe enregistré", Toast.LENGTH_SHORT).show()
                    showPasswordDialog = false
                }
            }
        )
    }

    if (showUsernameDialog) {
        UsernameDialog(
            current = user?.username ?: "",
            onDismiss = { showUsernameDialog = false },
            onConfirm = { name ->
                authVm.updateUsername(name)
                showUsernameDialog = false
            }
        )
    }

    if (showAppPicker) {
        val apps by vm.installedApps.collectAsStateWithLifecycle()
        AppPickerDialog(
            apps = apps,
            onDismiss = { showAppPicker = false },
            onAuto = {
                session.targetPackage = null
                session.targetAppLabel = null
                targetLabel = null
                showAppPicker = false
            },
            onPick = { app ->
                session.targetPackage = app.packageName
                session.targetAppLabel = app.label
                targetLabel = app.label
                showAppPicker = false
            }
        )
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Effacer les transactions ?") },
            text = { Text("Toutes les transactions enregistrées seront supprimées définitivement. L'utilisateur et les réglages sont conservés.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.clearAllTransactions()
                    showClearDialog = false
                    Toast.makeText(context, "Transactions effacées", Toast.LENGTH_SHORT).show()
                }) { Text("Effacer") }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text("Annuler") }
            }
        )
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column { content() }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun PinChangeDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    val valid = pin.length in 4..6 && pin.all { it.isDigit() } && pin == confirm
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouveau code PIN") },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) pin = it },
                    label = { Text("PIN (4 à 6 chiffres)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                VSpace(8)
                OutlinedTextField(
                    value = confirm,
                    onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) confirm = it },
                    label = { Text("Confirmer le PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { onConfirm(pin) }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
private fun PasswordDialog(
    hasPassword: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String?) -> Unit
) {
    var pwd by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (hasPassword) "Modifier le mot de passe" else "Définir un mot de passe") },
        text = {
            Column {
                OutlinedTextField(
                    value = pwd,
                    onValueChange = { pwd = it },
                    label = { Text("Mot de passe") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                Text(
                    "Laissez vide pour supprimer le mot de passe.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(pwd.ifEmpty { null }) }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
private fun UsernameDialog(current: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Identifiant") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nom d'utilisateur / e-mail") },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onConfirm(name.trim()) }) {
                Text("Enregistrer")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
private fun AppPickerDialog(
    apps: List<InstalledApp>,
    onDismiss: () -> Unit,
    onAuto: () -> Unit,
    onPick: (InstalledApp) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Application source") },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                item {
                    Text(
                        "Détection automatique (Dmoney)",
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onAuto() }
                            .padding(vertical = 14.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    HorizontalDivider()
                }
                items(apps, key = { it.packageName }) { app ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPick(app) }
                            .padding(vertical = 12.dp)
                    ) {
                        Text(app.label, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            app.packageName,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

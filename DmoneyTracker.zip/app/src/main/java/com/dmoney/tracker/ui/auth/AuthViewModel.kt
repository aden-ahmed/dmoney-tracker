package com.dmoney.tracker.ui.auth

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dmoney.tracker.data.Repository
import com.dmoney.tracker.data.User
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AuthViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository.get(app)

    val user: StateFlow<User?> = repo.observeUser()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    /** État déverrouillé, en mémoire uniquement (réauthentification à chaque lancement). */
    var unlocked by mutableStateOf(false)
        private set

    var error by mutableStateOf<String?>(null)
        private set

    fun clearError() { error = null }

    fun unlockWithPin(pin: String) {
        viewModelScope.launch {
            if (repo.verifyPin(pin)) {
                unlocked = true
                error = null
            } else {
                error = "Code PIN incorrect"
            }
        }
    }

    fun unlockWithPassword(password: String) {
        viewModelScope.launch {
            if (repo.verifyPassword(password)) {
                unlocked = true
                error = null
            } else {
                error = "Mot de passe incorrect"
            }
        }
    }

    fun onBiometricSuccess() {
        unlocked = true
        error = null
    }

    fun lock() {
        unlocked = false
    }

    // ---- Paramètres de sécurité ----
    fun changePin(newPin: String, onDone: (Boolean, String?) -> Unit) {
        if (!isValidPin(newPin)) {
            onDone(false, "Le PIN doit comporter 4 à 6 chiffres")
            return
        }
        viewModelScope.launch {
            repo.changePin(newPin)
            onDone(true, null)
        }
    }

    fun changePassword(newPassword: String?, onDone: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            repo.changePassword(newPassword)
            onDone(true, null)
        }
    }

    fun setBiometric(enabled: Boolean) {
        viewModelScope.launch { repo.setBiometric(enabled) }
    }

    fun updateUsername(username: String) {
        viewModelScope.launch { repo.updateUsername(username) }
    }

    companion object {
        fun isValidPin(pin: String): Boolean =
            pin.length in 4..6 && pin.all { it.isDigit() }
    }
}

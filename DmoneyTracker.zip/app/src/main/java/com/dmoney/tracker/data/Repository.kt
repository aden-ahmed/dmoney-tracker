package com.dmoney.tracker.data

import android.content.Context
import com.dmoney.tracker.security.Crypto
import kotlinx.coroutines.flow.Flow

/**
 * Point d'accès unique aux données (utilisateur + transactions).
 */
class Repository private constructor(
    private val userDao: UserDao,
    private val txnDao: TxnDao
) {
    // ---- Utilisateur ----
    fun observeUser(): Flow<User?> = userDao.observeUser()
    suspend fun getUser(): User? = userDao.getUser()
    suspend fun userCount(): Int = userDao.count()

    suspend fun ensureSeedUser() {
        if (userDao.count() == 0) {
            val salt = Crypto.generateSalt()
            userDao.upsert(
                User(
                    username = AppDatabase.SEED_USERNAME,
                    pinHash = Crypto.hash("3574", salt),
                    pinSalt = salt
                )
            )
        }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val u = userDao.getUser() ?: return false
        return Crypto.verify(pin, u.pinSalt, u.pinHash)
    }

    suspend fun verifyPassword(password: String): Boolean {
        val u = userDao.getUser() ?: return false
        val hash = u.passwordHash ?: return false
        val salt = u.passwordSalt ?: return false
        return Crypto.verify(password, salt, hash)
    }

    suspend fun changePin(newPin: String) {
        val salt = Crypto.generateSalt()
        userDao.updatePin(Crypto.hash(newPin, salt), salt)
    }

    suspend fun changePassword(newPassword: String?) {
        if (newPassword.isNullOrEmpty()) {
            userDao.updatePassword(null, null)
        } else {
            val salt = Crypto.generateSalt()
            userDao.updatePassword(Crypto.hash(newPassword, salt), salt)
        }
    }

    suspend fun setBiometric(enabled: Boolean) = userDao.setBiometric(enabled)
    suspend fun updateUsername(username: String) = userDao.updateUsername(username)

    // ---- Transactions ----
    suspend fun insertTxn(txn: Txn): Long = txnDao.insert(txn)
    fun observeAll(): Flow<List<Txn>> = txnDao.observeAll()
    fun observeBetween(from: Long, to: Long): Flow<List<Txn>> = txnDao.observeBetween(from, to)
    suspend fun getBetween(from: Long, to: Long): List<Txn> = txnDao.getBetween(from, to)
    suspend fun setExcluded(id: Long, excluded: Boolean) = txnDao.setExcluded(id, excluded)
    suspend fun txnCount(): Int = txnDao.count()
    suspend fun deleteAll() = txnDao.deleteAll()

    companion object {
        @Volatile
        private var INSTANCE: Repository? = null

        fun get(context: Context): Repository {
            return INSTANCE ?: synchronized(this) {
                val db = AppDatabase.get(context)
                INSTANCE ?: Repository(db.userDao(), db.txnDao()).also { INSTANCE = it }
            }
        }
    }
}

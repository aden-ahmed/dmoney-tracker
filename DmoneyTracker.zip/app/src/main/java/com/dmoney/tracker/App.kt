package com.dmoney.tracker

import android.app.Application
import com.dmoney.tracker.data.Repository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class App : Application() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        // Filet de sécurité : garantit que l'utilisateur unique existe.
        scope.launch {
            Repository.get(applicationContext).ensureSeedUser()
        }
    }
}

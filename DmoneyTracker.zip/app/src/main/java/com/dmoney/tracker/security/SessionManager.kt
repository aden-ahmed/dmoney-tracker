package com.dmoney.tracker.security

import android.content.Context

/**
 * Réglages non sensibles et état de capture, stockés dans SharedPreferences
 * (accès synchrone pratique pour le service de notifications).
 *
 * L'état « déverrouillé » n'est PAS persisté : il vit en mémoire (voir AppState)
 * pour forcer une authentification à chaque ouverture.
 */
class SessionManager(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("dmoney_session", Context.MODE_PRIVATE)

    /** Paquet applicatif à surveiller (null = détection automatique par le contenu). */
    var targetPackage: String?
        get() = prefs.getString(KEY_TARGET_PKG, null)
        set(value) = prefs.edit().putString(KEY_TARGET_PKG, value).apply()

    var targetAppLabel: String?
        get() = prefs.getString(KEY_TARGET_LABEL, null)
        set(value) = prefs.edit().putString(KEY_TARGET_LABEL, value).apply()

    /** Capture des notifications active. */
    var captureEnabled: Boolean
        get() = prefs.getBoolean(KEY_CAPTURE, true)
        set(value) = prefs.edit().putBoolean(KEY_CAPTURE, value).apply()

    companion object {
        private const val KEY_TARGET_PKG = "target_package"
        private const val KEY_TARGET_LABEL = "target_label"
        private const val KEY_CAPTURE = "capture_enabled"
    }
}

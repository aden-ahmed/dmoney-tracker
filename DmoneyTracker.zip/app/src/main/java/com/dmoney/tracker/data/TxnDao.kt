package com.dmoney.tracker.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TxnDao {

    /** Ignore si l'identifiant d'opération existe déjà (déduplication). */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(txn: Txn): Long

    @Query("SELECT * FROM txn ORDER BY occurredAt DESC")
    fun observeAll(): Flow<List<Txn>>

    /** Transactions dont la date d'opération est dans [from, to). */
    @Query("SELECT * FROM txn WHERE occurredAt >= :from AND occurredAt < :to ORDER BY occurredAt DESC")
    fun observeBetween(from: Long, to: Long): Flow<List<Txn>>

    @Query("SELECT * FROM txn WHERE occurredAt >= :from AND occurredAt < :to ORDER BY occurredAt DESC")
    suspend fun getBetween(from: Long, to: Long): List<Txn>

    @Query("UPDATE txn SET excluded = :excluded WHERE id = :id")
    suspend fun setExcluded(id: Long, excluded: Boolean)

    @Query("SELECT COUNT(*) FROM txn")
    suspend fun count(): Int

    @Delete
    suspend fun delete(txn: Txn)

    @Query("DELETE FROM txn")
    suspend fun deleteAll()
}

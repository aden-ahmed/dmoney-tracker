package com.dmoney.tracker.data

/**
 * Catégories d'opérations Dmoney.
 * La clé [key] est stockée en base ; le libellé [label] est affiché à l'utilisateur.
 */
enum class Category(val key: String, val label: String) {
    DEPOT("DEPOT", "Dépôt"),
    AIRTIME("AIRTIME", "Crédit téléphonique"),
    RETRAIT("RETRAIT", "Retrait"),
    AUTRE("AUTRE", "Autre");

    companion object {
        fun fromKey(key: String?): Category =
            entries.firstOrNull { it.key == key } ?: AUTRE

        /** Ordre d'affichage dans les rapports. */
        val displayOrder: List<Category> = listOf(DEPOT, AIRTIME, RETRAIT, AUTRE)
    }
}

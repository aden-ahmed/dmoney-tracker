package com.dmoney.tracker.ui.reports

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dmoney.tracker.data.Txn
import com.dmoney.tracker.util.Money

@Composable
fun CategoryReportCard(
    report: CategoryReport,
    transactions: List<Txn>,
    onToggleExclude: (Txn) -> Unit,
    modifier: Modifier = Modifier
) {
    var expandedAmount by remember { mutableStateOf<Long?>(null) }

    Card(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            // En-tête catégorie
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    report.category.label,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        Money.formatDjf(report.totalAmount),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "${report.totalCount} op.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            VSpaceSmall()
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            VSpaceSmall()

            // Tableau par dénomination (montants / comptages) — défilement horizontal.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                report.denominations.forEach { denom ->
                    DenominationColumn(
                        amountLabel = Money.format(denom.amount),
                        count = denom.count,
                        selected = expandedAmount == denom.amount,
                        onClick = {
                            expandedAmount = if (expandedAmount == denom.amount) null else denom.amount
                        }
                    )
                }
                // Colonne total
                DenominationColumn(
                    amountLabel = "TOTAL",
                    count = report.totalCount,
                    selected = false,
                    onClick = {},
                    emphasize = true
                )
            }

            // Détail de la dénomination sélectionnée : messages individuels.
            val amount = expandedAmount
            AnimatedVisibility(visible = amount != null) {
                if (amount != null) {
                    val items = transactions.filter {
                        it.categoryKey == report.category.key && it.amount == amount && !it.excluded
                    }.sortedByDescending { it.occurredAt }
                    Column(modifier = Modifier.padding(top = 12.dp)) {
                        Text(
                            "Messages de ${Money.formatDjf(amount)}",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            "Touchez « N'est pas compté » pour retirer un message du total.",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        VSpaceSmall()
                        items.forEach { txn ->
                            TxnDetailRow(txn = txn, onExclude = { onToggleExclude(txn) })
                            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DenominationColumn(
    amountLabel: String,
    count: Int,
    selected: Boolean,
    onClick: () -> Unit,
    emphasize: Boolean = false
) {
    val bg = when {
        selected -> MaterialTheme.colorScheme.primaryContainer
        emphasize -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    Column(
        modifier = Modifier
            .padding(end = 10.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .clickable(enabled = !emphasize) { onClick() }
            .widthIn(min = 72.dp)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            amountLabel,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            "$count",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun TxnDetailRow(txn: Txn, onExclude: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                txn.operationId?.let { "Op. $it" } ?: (txn.subType ?: "Opération"),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
            val sub = buildString {
                txn.counterparty?.let { append(it); append(" · ") }
                append(txn.occurredText ?: "")
            }
            if (sub.isNotBlank()) {
                Text(
                    sub,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        OutlinedButton(onClick = onExclude) {
            Text("N'est pas compté")
        }
    }
}

@Composable private fun VSpaceSmall() {
    androidx.compose.foundation.layout.Spacer(Modifier.padding(top = 6.dp))
}

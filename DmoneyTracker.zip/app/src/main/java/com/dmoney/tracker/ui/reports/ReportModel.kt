package com.dmoney.tracker.ui.reports

import com.dmoney.tracker.data.Category
import com.dmoney.tracker.data.Txn

/** Un montant (dénomination) et le nombre d'opérations à ce montant. */
data class DenominationCount(val amount: Long, val count: Int)

/** Rapport d'une catégorie : ventilation par montant + totaux. */
data class CategoryReport(
    val category: Category,
    val denominations: List<DenominationCount>,
    val totalCount: Int,
    val totalAmount: Long
)

object ReportBuilder {

    /**
     * Construit la ventilation par catégorie à partir des transactions.
     * Les transactions marquées « n'est pas compte » (excluded) sont ignorées,
     * ce qui fait baisser le comptage de la dénomination correspondante.
     */
    fun build(txns: List<Txn>): List<CategoryReport> {
        val active = txns.filter { !it.excluded }
        return Category.displayOrder.mapNotNull { cat ->
            val items = active.filter { it.categoryKey == cat.key }
            if (items.isEmpty()) return@mapNotNull null
            val denominations = items
                .groupBy { it.amount }
                .map { (amount, list) -> DenominationCount(amount, list.size) }
                .sortedBy { it.amount }
            CategoryReport(
                category = cat,
                denominations = denominations,
                totalCount = items.size,
                totalAmount = items.sumOf { it.amount }
            )
        }
    }

    fun grandCount(reports: List<CategoryReport>): Int = reports.sumOf { it.totalCount }
    fun grandAmount(reports: List<CategoryReport>): Long = reports.sumOf { it.totalAmount }
}

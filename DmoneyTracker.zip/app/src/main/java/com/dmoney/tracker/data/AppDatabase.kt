package com.dmoney.tracker.data

import android.content.ContentValues
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.dmoney.tracker.security.Crypto

@Database(
    entities = [User::class, Txn::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun txnDao(): TxnDao

    companion object {
        /** Identifiants de l'utilisateur pré-créé. */
        const val SEED_USERNAME = "ahmedaden365@gmail.com"
        private const val SEED_PIN = "3574"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: build(context).also { INSTANCE = it }
            }
        }

        private fun build(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "dmoney.db"
            )
                .addCallback(SeedCallback)
                .build()
        }

        /** Crée l'utilisateur unique à la création de la base. */
        private object SeedCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                val salt = Crypto.generateSalt()
                val pinHash = Crypto.hash(SEED_PIN, salt)
                val values = ContentValues().apply {
                    put("id", User.SINGLE_USER_ID)
                    put("username", SEED_USERNAME)
                    put("pinHash", pinHash)
                    put("pinSalt", salt)
                    putNull("passwordHash")
                    putNull("passwordSalt")
                    put("biometricEnabled", 0)
                }
                db.insert("user", android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE, values)
            }
        }
    }
}

package com.dmoney.tracker.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Plage temporelle [from, to) en epoch millis. */
data class DateRange(val from: Long, val to: Long)

object DateUtils {

    private fun cal(millis: Long): Calendar =
        Calendar.getInstance().apply { timeInMillis = millis }

    private fun Calendar.atStartOfDay(): Calendar = apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }

    fun day(ref: Long): DateRange {
        val start = cal(ref).atStartOfDay()
        val from = start.timeInMillis
        start.add(Calendar.DAY_OF_MONTH, 1)
        return DateRange(from, start.timeInMillis)
    }

    fun week(ref: Long): DateRange {
        val c = cal(ref).atStartOfDay()
        c.firstDayOfWeek = Calendar.MONDAY
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        val from = c.timeInMillis
        c.add(Calendar.DAY_OF_MONTH, 7)
        return DateRange(from, c.timeInMillis)
    }

    fun month(ref: Long): DateRange {
        val c = cal(ref).atStartOfDay()
        c.set(Calendar.DAY_OF_MONTH, 1)
        val from = c.timeInMillis
        c.add(Calendar.MONTH, 1)
        return DateRange(from, c.timeInMillis)
    }

    /** Plage personnalisée inclusive sur les deux dates (jour entier). */
    fun range(fromDay: Long, toDay: Long): DateRange {
        val start = cal(fromDay).atStartOfDay().timeInMillis
        val endCal = cal(toDay).atStartOfDay()
        endCal.add(Calendar.DAY_OF_MONTH, 1)
        return DateRange(start, endCal.timeInMillis)
    }

    fun shiftDay(ref: Long, delta: Int): Long =
        cal(ref).apply { add(Calendar.DAY_OF_MONTH, delta) }.timeInMillis

    fun shiftWeek(ref: Long, delta: Int): Long =
        cal(ref).apply { add(Calendar.WEEK_OF_YEAR, delta) }.timeInMillis

    fun shiftMonth(ref: Long, delta: Int): Long =
        cal(ref).apply { add(Calendar.MONTH, delta) }.timeInMillis

    private val dayFmt = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)
    private val dayTimeFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.FRANCE)
    private val monthFmt = SimpleDateFormat("MMMM yyyy", Locale.FRANCE)
    private val weekFmt = SimpleDateFormat("dd MMM", Locale.FRANCE)

    fun formatDay(millis: Long): String = dayFmt.format(millis)
    fun formatDayTime(millis: Long): String = dayTimeFmt.format(millis)
    fun formatTime(millis: Long): String = timeFmt.format(millis)
    fun formatMonth(millis: Long): String =
        monthFmt.format(millis).replaceFirstChar { it.uppercase() }

    fun formatWeekLabel(range: DateRange): String {
        val end = range.to - 1
        return "${weekFmt.format(range.from)} – ${weekFmt.format(end)}"
    }
}

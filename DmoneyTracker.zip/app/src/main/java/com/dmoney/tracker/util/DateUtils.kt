package com.dmoney.tracker.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Plage temporelle [from, to) en epoch millis. */
data class DateRange(val from: Long, val to: Long)

object DateUtils {

    private fun cal(millis: Long): Calendar =
        Calendar.getInstance().apply { timeInMillis = millis }

    private fun Calendar.atStartOfDay(): Calendar = apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }

    fun day(ref: Long): DateRange {
        val start = cal(ref).atStartOfDay()
        val from = start.timeInMillis
        start.add(Calendar.DAY_OF_MONTH, 1)
        return DateRange(from, start.timeInMillis)
    }

    fun week(ref: Long): DateRange {
        val c = cal(ref).atStartOfDay()
        c.firstDayOfWeek = Calendar.MONDAY
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        val from = c.timeInMillis
        c.add(Calendar.DAY_OF_MONTH, 7)
        return DateRange(from, c.timeInMillis)
    }

    fun month(ref: Long): DateRange {
        val c = cal(ref).atStartOfDay()
        c.set(Calendar.DAY_OF_MONTH, 1)
        val from = c.timeInMillis
        c.add(Calendar.MONTH, 1)
        return DateRange(from, c.timeInMillis)
    }

    /** Plage personnalisée inclusive sur les deux dates (jour entier). */
    fun range(fromDay: Long, toDay: Long): DateRange {
        val start = cal(fromDay).atStartOfDay().timeInMillis
        val endCal = cal(toDay).atStartOfDay()
        endCal.add(Calendar.DAY_OF_MONTH, 1)
        return DateRange(start, endCal.timeInMillis)
    }

    /** Minuit (début de journée) du jour contenant [ref]. */
    fun startOfDay(ref: Long): Long = cal(ref).atStartOfDay().timeInMillis

    /**
     * Fenêtre horaire à l'intérieur du jour [dayRef] :
     * de [startSecOfDay] à [endSecOfDay] (secondes depuis minuit).
     * La seconde de fin est incluse. Les bornes sont réordonnées si besoin.
     */
    fun hourWindow(dayRef: Long, startSecOfDay: Int, endSecOfDay: Int): DateRange {
        val base = cal(dayRef).atStartOfDay().timeInMillis
        val lo = minOf(startSecOfDay, endSecOfDay)
        val hi = maxOf(startSecOfDay, endSecOfDay)
        val from = base + lo * 1000L
        val to = base + (hi + 1) * 1000L // +1s pour inclure la seconde de fin
        return DateRange(from, to)
    }

    /** Compose des secondes-depuis-minuit à partir de heures/minutes/secondes. */
    fun secOfDay(hour: Int, minute: Int, second: Int): Int =
        (hour.coerceIn(0, 23) * 3600) + (minute.coerceIn(0, 59) * 60) + second.coerceIn(0, 59)

    fun hourOf(secOfDay: Int): Int = (secOfDay / 3600) % 24
    fun minuteOf(secOfDay: Int): Int = (secOfDay % 3600) / 60
    fun secondOf(secOfDay: Int): Int = secOfDay % 60

    /** Formate des secondes-depuis-minuit en "HH:mm:ss". */
    fun formatSecOfDay(secOfDay: Int): String =
        "%02d:%02d:%02d".format(hourOf(secOfDay), minuteOf(secOfDay), secondOf(secOfDay))

    fun shiftDay(ref: Long, delta: Int): Long =
        cal(ref).apply { add(Calendar.DAY_OF_MONTH, delta) }.timeInMillis

    fun shiftWeek(ref: Long, delta: Int): Long =
        cal(ref).apply { add(Calendar.WEEK_OF_YEAR, delta) }.timeInMillis

    fun shiftMonth(ref: Long, delta: Int): Long =
        cal(ref).apply { add(Calendar.MONTH, delta) }.timeInMillis

    private val dayFmt = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)
    private val dayTimeFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.FRANCE)
    private val monthFmt = SimpleDateFormat("MMMM yyyy", Locale.FRANCE)
    private val weekFmt = SimpleDateFormat("dd MMM", Locale.FRANCE)

    fun formatDay(millis: Long): String = dayFmt.format(millis)
    fun formatDayTime(millis: Long): String = dayTimeFmt.format(millis)
    fun formatTime(millis: Long): String = timeFmt.format(millis)
    fun formatMonth(millis: Long): String =
        monthFmt.format(millis).replaceFirstChar { it.uppercase() }

    fun formatWeekLabel(range: DateRange): String {
        val end = range.to - 1
        return "${weekFmt.format(range.from)} – ${weekFmt.format(end)}"
    }
}

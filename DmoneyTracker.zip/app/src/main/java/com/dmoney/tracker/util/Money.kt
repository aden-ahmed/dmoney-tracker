package com.dmoney.tracker.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/** Formatage monétaire DJF (séparateur de milliers par virgule, comme Dmoney). */
object Money {
    private val symbols = DecimalFormatSymbols(Locale.US).apply { groupingSeparator = ',' }
    private val fmt = DecimalFormat("#,###", symbols)

    fun format(amount: Long): String = fmt.format(amount)
    fun formatDjf(amount: Long): String = "${fmt.format(amount)} DJF"
    fun formatFdj(amount: Long): String = "${fmt.format(amount)} FDJ"
}

package com.dmoney.tracker.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {

    @Query("SELECT * FROM user WHERE id = :id LIMIT 1")
    suspend fun getUser(id: Int = User.SINGLE_USER_ID): User?

    @Query("SELECT * FROM user WHERE id = :id LIMIT 1")
    fun observeUser(id: Int = User.SINGLE_USER_ID): Flow<User?>

    @Query("SELECT COUNT(*) FROM user")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(user: User)

    @Query("UPDATE user SET pinHash = :pinHash, pinSalt = :pinSalt WHERE id = :id")
    suspend fun updatePin(pinHash: String, pinSalt: String, id: Int = User.SINGLE_USER_ID)

    @Query("UPDATE user SET passwordHash = :passwordHash, passwordSalt = :passwordSalt WHERE id = :id")
    suspend fun updatePassword(passwordHash: String?, passwordSalt: String?, id: Int = User.SINGLE_USER_ID)

    @Query("UPDATE user SET biometricEnabled = :enabled WHERE id = :id")
    suspend fun setBiometric(enabled: Boolean, id: Int = User.SINGLE_USER_ID)

    @Query("UPDATE user SET username = :username WHERE id = :id")
    suspend fun updateUsername(username: String, id: Int = User.SINGLE_USER_ID)
}

package com.dmoney.tracker.notif

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.dmoney.tracker.data.Repository
import com.dmoney.tracker.parser.DmoneyParser
import com.dmoney.tracker.security.SessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Écoute les notifications du système et enregistre celles de Dmoney.
 *
 * L'utilisateur doit accorder l'accès dans :
 * Paramètres > Applications > Accès aux notifications.
 */
class DmoneyNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var repo: Repository
    private lateinit var session: SessionManager

    override fun onCreate() {
        super.onCreate()
        repo = Repository.get(applicationContext)
        session = SessionManager(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        if (!session.captureEnabled) return

        val pkg = sbn.packageName
        val target = session.targetPackage
        // Filtre par paquet si l'utilisateur en a choisi un.
        if (target != null && target != pkg) return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.joinToString(" ") { it.toString() }
        val content = listOfNotNull(bigText, text, lines)
            .firstOrNull { it.isNotBlank() } ?: return

        val appLabel = loadAppLabel(pkg)

        // En détection automatique, on écarte explicitement « D-money » (app différente).
        if (target == null && DmoneyParser.isExcludedSource(appLabel, title)) return

        val txn = DmoneyParser.parse(
            text = content,
            title = title,
            sourcePackage = pkg,
            sourceApp = appLabel,
            receivedAt = sbn.postTime.takeIf { it > 0 } ?: System.currentTimeMillis()
        ) ?: return

        scope.launch { repo.insertTxn(txn) }
    }

    private fun loadAppLabel(pkg: String?): String? {
        if (pkg == null) return null
        return try {
            val pm = packageManager
            val info = pm.getApplicationInfo(pkg, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}

package com.dmoney.tracker.ui.transactions

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dmoney.tracker.data.Category
import com.dmoney.tracker.data.Repository
import com.dmoney.tracker.data.Txn
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TransactionsViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository.get(app)

    /** null = toutes les catégories. */
    private val filter = MutableStateFlow<String?>(null)
    var selectedCategory by mutableStateOf<Category?>(null)
        private set

    val transactions: StateFlow<List<Txn>> =
        combine(repo.observeAll(), filter) { list, f ->
            if (f == null) list else list.filter { it.categoryKey == f }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setFilter(category: Category?) {
        selectedCategory = category
        filter.value = category?.key
    }

    fun toggleExcluded(txn: Txn) {
        viewModelScope.launch { repo.setExcluded(txn.id, !txn.excluded) }
    }
}

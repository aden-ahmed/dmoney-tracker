package com.dmoney.tracker.ui.transactions

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dmoney.tracker.data.Category
import com.dmoney.tracker.data.Repository
import com.dmoney.tracker.data.Txn
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TransactionsViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository.get(app)

    /** null = toutes les catégories. */
    private val filter = MutableStateFlow<String?>(null)
    var selectedCategory by mutableStateOf<Category?>(null)
        private set

    /** Texte de recherche (identifiant, numéro, montant...). */
    private val query = MutableStateFlow("")
    var searchQuery by mutableStateOf("")
        private set

    val transactions: StateFlow<List<Txn>> =
        combine(repo.observeAll(), filter, query) { list, f, q ->
            val byCategory = if (f == null) list else list.filter { it.categoryKey == f }
            val needle = q.trim()
            if (needle.isEmpty()) {
                byCategory
            } else {
                val lower = needle.lowercase()
                byCategory.filter { txn ->
                    txn.operationId?.lowercase()?.contains(lower) == true ||
                        txn.counterparty?.lowercase()?.contains(lower) == true ||
                        txn.amount.toString().contains(needle) ||
                        txn.subType?.lowercase()?.contains(lower) == true ||
                        txn.rawMessage.lowercase().contains(lower)
                }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setFilter(category: Category?) {
        selectedCategory = category
        filter.value = category?.key
    }

    fun setSearch(text: String) {
        searchQuery = text
        query.value = text
    }

    fun toggleExcluded(txn: Txn) {
        viewModelScope.launch { repo.setExcluded(txn.id, !txn.excluded) }
    }
}

package com.dmoney.tracker.security

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Hachage des secrets (PIN, mot de passe) avec sel aléatoire + SHA-256.
 * Aucune donnée sensible n'est stockée en clair.
 */
object Crypto {

    private const val ITERATIONS = 10_000

    fun generateSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    /** SHA-256 itéré sur (sel + secret). Retour en Base64. */
    fun hash(secret: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        var data = (salt + secret).toByteArray(Charsets.UTF_8)
        repeat(ITERATIONS) {
            md.reset()
            data = md.digest(data)
        }
        return Base64.encodeToString(data, Base64.NO_WRAP)
    }

    fun verify(secret: String, salt: String, expectedHash: String): Boolean {
        val computed = hash(secret, salt)
        // Comparaison à temps constant.
        if (computed.length != expectedHash.length) return false
        var diff = 0
        for (i in computed.indices) {
            diff = diff or (computed[i].code xor expectedHash[i].code)
        }
        return diff == 0
    }
}

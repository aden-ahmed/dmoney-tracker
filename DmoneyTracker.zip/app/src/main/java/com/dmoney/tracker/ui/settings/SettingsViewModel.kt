package com.dmoney.tracker.ui.settings

import android.app.Application
import android.content.pm.ApplicationInfo
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dmoney.tracker.data.Repository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class InstalledApp(val packageName: String, val label: String)

class SettingsViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository.get(app)

    val txnCount: StateFlow<Int> =
        repo.observeAll().map { it.size }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val installedApps = MutableStateFlow<List<InstalledApp>>(emptyList())

    fun loadInstalledApps() {
        viewModelScope.launch {
            val pm = getApplication<Application>().packageManager
            val apps = withContext(Dispatchers.IO) {
                pm.getInstalledApplications(0)
                    .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 || it.enabled }
                    .map { InstalledApp(it.packageName, pm.getApplicationLabel(it).toString()) }
                    .distinctBy { it.packageName }
                    .sortedBy { it.label.lowercase() }
            }
            installedApps.value = apps
        }
    }

    fun clearAllTransactions() {
        viewModelScope.launch { repo.deleteAll() }
    }
}

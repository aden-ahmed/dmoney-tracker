package com.dmoney.tracker.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Une transaction extraite d'une notification Dmoney.
 *
 * [operationId] est indexé de façon unique pour éviter d'enregistrer deux fois
 * la même opération (SQLite autorise plusieurs valeurs NULL dans un index unique,
 * donc les messages "Autre" sans identifiant ne se bloquent pas entre eux).
 */
@Entity(
    tableName = "txn",
    indices = [Index(value = ["operationId"], unique = true)]
)
data class Txn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,

    /** Clé de catégorie : DEPOT, AIRTIME, RETRAIT, AUTRE. */
    val categoryKey: String,

    /** Sous-type lisible (utile surtout pour la catégorie AUTRE). */
    val subType: String? = null,

    /** Montant principal de l'opération, en DJF (entier). */
    val amount: Long,

    /** Frais appliqués, en DJF. */
    val fees: Long = 0,

    /** Numéro de l'abonné / du téléphone / identifiant de l'agent concerné. */
    val counterparty: String? = null,

    /** Type de contrepartie : ABONNE, NUMERO, AGENT. */
    val counterpartyType: String? = null,

    /** Nouveau solde du compte principal après l'opération (si présent). */
    val balanceAfter: Long? = null,

    /** Identifiant de l'opération fourni par Dmoney. */
    val operationId: String? = null,

    /** Date/heure de l'opération (epoch millis) extraite du message. */
    val occurredAt: Long,

    /** Date/heure brute telle qu'écrite dans le message. */
    val occurredText: String? = null,

    /** Moment de capture de la notification (epoch millis). */
    val receivedAt: Long,

    /** true => exclu des rapports ("n'est pas compte"). */
    val excluded: Boolean = false,

    /** Texte brut complet de la notification. */
    val rawMessage: String,

    /** Paquet applicatif source (ex: com.dmoney...). */
    val sourcePackage: String? = null,

    /** Nom d'application source affiché. */
    val sourceApp: String? = null,

    /** Titre de la notification. */
    val title: String? = null
)

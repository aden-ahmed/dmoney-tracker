BASE DE DONNÉES — Dmoney Tracker
=================================

Fichiers
--------
- dmoney.db   : base SQLite autonome (ouvrable avec DB Browser for SQLite,
                sqlite3, etc.). Contient l'utilisateur pré-créé et 56 transactions
                d'exemple, dont les 3 messages réels fournis.
- schema.sql  : export SQL complet (CREATE + INSERT) de dmoney.db.

Utilisateur pré-créé
--------------------
  table  : user
  id        = 1
  username  = ahmedaden365@gmail.com
  pinHash   = SHA-256 salé, 10 000 itérations, encodé Base64
  pinSalt   = sel associé
  Code PIN clair correspondant : 3574

  Le hachage est identique à celui de l'application (security/Crypto.kt), donc
  ce même utilisateur est reconnu si la base est utilisée par l'app.

Tables
------
  user : utilisateur unique (identifiant, PIN/mot de passe hachés, biométrie).
  txn  : transactions extraites des notifications Dmoney.
         Colonnes principales :
           categoryKey      DEPOT | AIRTIME | RETRAIT | AUTRE
           subType          libellé déduit (ex. « Crédit abonné »)
           amount           montant en DJF (entier)
           fees             frais en DJF
           counterparty     abonné / numéro / agent
           counterpartyType ABONNE | NUMERO | AGENT
           balanceAfter     nouveau solde (si présent dans le message)
           operationId      identifiant de l'opération (index unique)
           occurredAt       date/heure de l'opération (epoch millis)
           occurredText     date/heure brute du message
           excluded         1 = « n'est pas compté » (exclu des rapports)
           rawMessage       texte complet de la notification

Correspondance avec Room
------------------------
  Le schéma reproduit exactement les entités Room (version 1) de l'application.
  L'application gère toutefois sa propre base dans son stockage interne :
    /data/data/com.dmoney.tracker/databases/dmoney.db
  et recrée l'utilisateur au premier lancement. Le fichier ci-joint sert
  d'inspection et de référence. Le schéma JSON officiel est généré par KSP
  lors de la compilation, dans le dossier schemas/.

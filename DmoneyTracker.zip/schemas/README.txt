Ce dossier reçoit le schéma Room exporté automatiquement (format JSON) lors de
la compilation, grâce à l'option KSP « room.schemaLocation » déclarée dans
app/build.gradle.kts.

Après un premier build, vous y trouverez :
  com.dmoney.tracker.data.AppDatabase/1.json

Ce fichier décrit la structure exacte de la base (version 1), utile pour les
futures migrations. Il est volontairement vide avant la première compilation.

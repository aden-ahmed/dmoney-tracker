# Dmoney Tracker

Application Android (Kotlin + Jetpack Compose) qui lit les **notifications de Dmoney**,
décompose chaque message en opérations, les enregistre dans une **base de données locale
(Room / SQLite)** sur le téléphone, et produit des **rapports** (journalier, hebdomadaire,
mensuel ou par plage de dates) ventilés par catégorie et par montant.

> ⚠️ **À propos de l'APK** — L'APK n'a pas pu être compilé dans l'environnement qui a généré
> ce projet (les dépôts Google Maven et le SDK Android y sont bloqués par une politique réseau).
> Ce dossier contient **tout le projet prêt à compiler** : vous obtenez l'APK en **un clic**
> dans Android Studio, ou avec `./gradlew assembleDebug`. Voir **« Générer l'APK »** ci-dessous.

---

## Identifiants pré-créés

| Champ | Valeur |
|-------|--------|
| Utilisateur (identifiant) | `ahmedaden365@gmail.com` |
| Code PIN | `3574` |

L'utilisateur est créé **automatiquement au premier lancement** (dans la base locale).
Une copie autonome de la base est aussi fournie dans `database/` (voir plus bas).

---

## Fonctionnalités

- **Lecture des notifications** via un `NotificationListenerService` (autorisation requise).
- **Décomposition automatique** de chaque message Dmoney :
  - **Dépôt (crédit abonné)** — ex. « Vous avez crédité avec succès l'abonné 2537… » →
    montant débité, numéro de l'abonné, nouveau solde, identifiant d'opération, date.
  - **Crédit téléphonique** — ex. « Vous avez acheté du crédit téléphonique d'une valeur de… » →
    montant, numéro, frais, solde, identifiant, date.
  - **Retrait** — ex. « Votre retrait d'espèce est approuvé… » →
    montant, agent, frais, identifiant, date.
  - **Autre** — tout autre message Dmoney est conservé avec un sous-type déduit
    (transfert, paiement, facture, commission…).
- **Distinction Dmoney / D-money** : les sources nommées « D-money / D money » sont ignorées,
  et l'on peut en plus **choisir l'application source exacte** dans les réglages.
- **Base de données locale** (Room) : chaque opération et son message brut sont enregistrés ;
  déduplication par identifiant d'opération.
- **Rapports** par **Jour / Semaine / Mois / Plage de dates**, séparés par catégorie, avec,
  pour chaque catégorie, le détail **par montant** et le **nombre** d'opérations, par exemple :

  ```
  Dépôt
  200    150    500    1 000   3 000   3 850
   9      6      13      8       2       1
  ```

- **« N'est pas compté »** : on peut toucher un message précis pour le retirer du total ;
  le comptage de la dénomination correspondante diminue (ex. 200 → de 9 à 8). Réversible
  depuis l'onglet **Transactions**.
- **Sécurité** : un seul utilisateur ; connexion par **code PIN (4 à 6 chiffres, modifiable)**,
  **déverrouillage par empreinte digitale**, et **mot de passe** optionnel. Secrets hachés
  (SHA-256 salé, 10 000 itérations) — jamais stockés en clair.
- **Interface moderne** Material 3 (thème clair/sombre, couleurs dynamiques Android 12+).

---

## Générer l'APK

Pré-requis communs : **JDK 17** et le **SDK Android (API 34)**. Une connexion Internet est
nécessaire à la première compilation (téléchargement de Gradle 8.9, de l'Android Gradle Plugin
8.5.2 et des bibliothèques AndroidX / Compose / Room).

### Option A — Android Studio (le plus simple)

1. Installer **Android Studio** (version Koala / 2024.1 ou plus récente).
2. **File → Open…** puis sélectionner le dossier `DmoneyTracker`.
3. Laisser la **synchronisation Gradle** se terminer (Android Studio propose d'installer
   automatiquement le SDK 34 et les build-tools manquants — accepter).
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. L'APK (debug) est généré ici :
   `app/build/outputs/apk/debug/app-debug.apk`
   (Android Studio affiche un lien **« locate »** pour l'ouvrir.)
6. Pour l'installer : brancher le téléphone (débogage USB activé) puis **Run ▶**, ou copier
   l'APK sur le téléphone et l'ouvrir.

### Option B — Ligne de commande

```bash
# 1. Installer le SDK (si besoin) et accepter les licences
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
export ANDROID_HOME=$HOME/Android/Sdk        # adapter au chemin réel

# 2. Depuis la racine du projet
cd DmoneyTracker
./gradlew assembleDebug                        # Windows : gradlew.bat assembleDebug

# 3. APK généré :
#    app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Option C — GitHub Actions (aucune installation sur votre ordinateur)

Le projet contient déjà un workflow (`.github/workflows/android.yml`) qui compile l'APK
dans le cloud, gratuitement.

1. Créez un compte sur https://github.com puis un nouveau dépôt (New repository).
2. Téléversez le contenu de ce dossier (bouton **Add file → Upload files**, ou `git push`).
3. Onglet **Actions** → le build **« Build APK »** démarre tout seul (sinon :
   *Run workflow*). Attendez ~3–5 min (pastille verte).
4. Ouvrez le build terminé → section **Artifacts** → téléchargez **`app-debug-apk`**.
   Il contient `app-debug.apk`, prêt à installer sur le téléphone.

> Sur le téléphone : autorisez « Installer des applications inconnues » pour votre
> navigateur/gestionnaire de fichiers, puis ouvrez l'APK.

### APK de release (signé)

```bash
keytool -genkey -v -keystore dmoney.jks -keyalg RSA -keysize 2048 -validity 10000 -alias dmoney
# Renseigner signingConfigs dans app/build.gradle.kts, puis :
./gradlew assembleRelease
```

---

## Première utilisation

1. Lancer l'application → écran de connexion. Saisir le **PIN `3574`**.
2. Sur le tableau de bord, toucher **« Activer l'accès »** pour autoriser la lecture des
   notifications (*Paramètres → Accès aux notifications → Dmoney Tracker*).
3. (Optionnel) **Réglages → Application source** : choisir précisément l'app **Dmoney**
   si plusieurs applications de paiement sont installées.
4. (Optionnel) **Réglages → Déverrouillage par empreinte** pour activer la biométrie.
5. Les nouveaux messages Dmoney sont alors capturés et apparaissent dans **Rapports** et
   **Transactions**. Un jeu de données de démonstration est déjà présent (voir `database/`).

---

## Base de données (`database/`)

| Fichier | Description |
|---------|-------------|
| `dmoney.db` | Copie SQLite autonome : l'utilisateur pré-créé + 56 transactions d'exemple (dont vos 3 messages). Ouvrable avec *DB Browser for SQLite*. |
| `schema.sql` | Export SQL complet (schéma + données) de `dmoney.db`. |
| `README.txt` | Détails et correspondance avec le schéma Room. |

> L'application gère sa **propre** base Room dans son stockage interne
> (`/data/data/com.dmoney.tracker/databases/dmoney.db`) et recrée l'utilisateur au
> premier lancement. Le fichier fourni sert à l'inspection et de référence.

---

## Structure du projet

```
DmoneyTracker/
├─ app/
│  ├─ build.gradle.kts
│  └─ src/main/
│     ├─ AndroidManifest.xml
│     ├─ java/com/dmoney/tracker/
│     │  ├─ App.kt, MainActivity.kt
│     │  ├─ data/        (Room : User, Txn, DAOs, AppDatabase, Repository, Category)
│     │  ├─ parser/      (DmoneyParser : décomposition des messages)
│     │  ├─ notif/       (NotificationListenerService + accès)
│     │  ├─ security/    (Crypto, BiometricAuth, SessionManager)
│     │  ├─ util/        (DateUtils, Money)
│     │  └─ ui/          (auth, home, reports, transactions, settings, theme, components)
│     └─ res/            (thème, icône adaptative, strings, règles de sauvegarde)
├─ database/             (dmoney.db, schema.sql, README.txt)
├─ gradle/wrapper/       (wrapper Gradle 8.9)
├─ build.gradle.kts, settings.gradle.kts, gradle.properties
└─ gradlew, gradlew.bat
```

## Détails techniques

- **minSdk 26**, **targetSdk / compileSdk 34**.
- Android Gradle Plugin **8.5.2**, Kotlin **1.9.24**, Compose Compiler **1.5.14**,
  Compose BOM **2024.06.00**, Room **2.6.1** (via KSP), Biometric **1.1.0**.
- Les montants Dmoney (ex. `11,852`, `1,000`) sont normalisés en entiers DJF.
